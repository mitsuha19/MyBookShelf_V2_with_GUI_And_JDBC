
import Repository.MyBookRepository;
import Repository.MyBookRepositoryImpl;
import Service.MyBookService;
import Service.MyBookServiceImpl;
import View.loginFrame;

public class App {

    public static void main(String[] args) {
        MyBookRepository myBookRepository = new MyBookRepositoryImpl();
        MyBookService myBookService = new MyBookServiceImpl(myBookRepository);
        loginFrame lF = new loginFrame();
        lF.setMyBookService(myBookService);
        lF.setVisible(true);
    }
    
    
    
}
