package Repository;

import Entity.MyBook;

import java.util.ArrayList;

public interface MyBookRepository {
    
    public ArrayList<MyBook> getAll(String keyword,String status);
    
    public MyBook get(int isbn);
    
    public boolean add(MyBook myBook);
    
    public boolean remove(int isbn);
    
    public boolean changeStatus(int isbn, boolean status);
    
    public boolean changeTittle(int isbn, String judul);
    
    public boolean updateReading(int isbn, int currentPages);
    
    public ArrayList<MyBook> getWithoutArchived();
    
    public ArrayList<MyBook> getOnlyArchived();
    
    public boolean updateArchived(int isbn, boolean isArchived);

}
