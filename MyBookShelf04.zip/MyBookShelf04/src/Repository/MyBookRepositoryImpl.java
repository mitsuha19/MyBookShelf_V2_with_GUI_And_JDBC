package Repository;

import Entity.MyBook;
import Util.DB;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;

public class MyBookRepositoryImpl implements MyBookRepository {

    //ArrayList<MyBook> data = new ArrayList<MyBook>();
    private final DB db;

    public MyBookRepositoryImpl() {
        db = new DB();
    }

    @Override
    public ArrayList<MyBook> getAll(String keyword, String status) {
        String query = "SELECT * FROM users WHERE judul LIKE ?";
        ResultSet resultSet = db.getAllData(query, keyword);
        ArrayList<MyBook> model = new ArrayList<>();

        if (resultSet != null) {
            try {
                while (resultSet.next()) {
                    int isbn = resultSet.getInt("isbn");
                    String judul = resultSet.getString("judul");
                    String penulis = resultSet.getString("penulis");
                    String penerbit = resultSet.getString("penerbit");
                    int tahun_terbit = resultSet.getInt("tahun_terbit");
                    int jumlah_halaman = resultSet.getInt("jumlah_halaman");
                    String infoStatus = resultSet.getString("status");
                    boolean stat = false;
                    if (infoStatus.equalsIgnoreCase("Archived")) {
                        stat = true;
                    }
                    MyBook myBook = new MyBook(isbn, judul, penulis, penerbit, tahun_terbit, jumlah_halaman);
                    myBook.setArchived(stat);
                    if (infoStatus.equalsIgnoreCase(status)) {
                        model.add(myBook);
                    }
                }
            } catch (SQLException ex) {
                //Terjadi kesalahan pada JDBC
            }
        }
        return model;
    }

    @Override
    public MyBook get(int isbn) {
        MyBook myBook = null;
        String query = "SELECT * FROM users WHERE isbn = ?";
        ResultSet resultSet = db.getByISBN(query, isbn);
        if (resultSet != null) {
            try {
                while (resultSet.next()) {
                    myBook = new MyBook(resultSet.getInt("isbn"), resultSet.getString("judul"), resultSet.getString("penulis"), resultSet.getString("penerbit"), resultSet.getInt("tahun_terbit"), resultSet.getInt("jumlah_halaman"));
                    myBook.setCurrentPages(resultSet.getInt("halaman_baca"));
                    break;
                }
            } catch (Exception e) {
                //Terjadi kesalahan pada JDBC
                System.out.println("Book Not Found");
            }
        } else {
            System.out.println("Book Not Found 2");
        }
        return myBook;
    }

    @Override
    public boolean add(MyBook myBook) {
        String query = "INSERT INTO users (isbn, judul, penulis, penerbit, tahun_terbit, jumlah_halaman, status, halaman_baca) VALUES (?,?,?,?,?,?,?,?)";
        String status = "Tidak Archived";
        if (myBook.isArchived()) {
            status = "Archived";
        }
        String[] values = new String[]{String.valueOf(myBook.getIsbn()), myBook.getTitle(), myBook.getAuthor(), myBook.getPublisher(), String.valueOf(myBook.getYear()), String.valueOf(myBook.getTotalPages()), status, String.valueOf(0)};
        return db.update(query, values);
    }

    @Override
    public boolean remove(int isbn) {

        String query = "DELETE FROM users WHERE isbn = ?";
        String[] values = new String[]{String.valueOf(isbn)};
        return db.update(query, values);
    }

    @Override
    public boolean changeStatus(int isbn, boolean status) {
        String query = "UPDATE users SET status = ? WHERE isbn= ?";
        String stat = "Tidak Archived";
        if (status) {
            stat = "Archived";
        }
        String[] values = new String[]{stat, String.valueOf(isbn)};
        return db.update(query, values);

    }

    @Override
    public boolean changeTittle(int isbn, String judul) {
        String query = "UPDATE users SET judul = ? WHERE isbn= ?";

        String[] values = new String[]{judul, String.valueOf(isbn)};
        return db.update(query, values);

    }

    @Override
    public boolean updateReading(int isbn, int currentPages) {
        String query = "UPDATE users SET halaman_baca = ? WHERE isbn= ?";

        String[] values = new String[]{String.valueOf(currentPages), String.valueOf(isbn)};
        return db.update(query, values);
    }

    @Override
    public ArrayList<MyBook> getWithoutArchived() {
//        ArrayList<MyBook> save = new ArrayList<>();
//        for (MyBook myBook : data) {
//            if (!myBook.isArchived()) {
//                save.add(myBook);
//            }
//        }
        return null;
    }

    @Override
    public ArrayList<MyBook> getOnlyArchived() {
//        ArrayList<MyBook> save = new ArrayList<>();
//        for (MyBook myBook : data) {
//            if (myBook.isArchived()) {
//                save.add(myBook);
//            }
//        }

        return null;
    }

    @Override
    public boolean updateArchived(int isbn, boolean isArchived) {
//        for (MyBook myBook : data) {
//            if (myBook.getIsbn() == isbn) {
//                myBook.setArchived(isArchived);
//                return true;
//            }
//        }
        return false;
    }

}
