/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View.pages;

/**
 *
 * @author ASUS
 */
public class PageController {
    public static homepage hp = new homepage();
    public static MyBookPage bookPage = new MyBookPage();
    public static MyArchivePage archivePage = new MyArchivePage();
    public static AboutPage aboutPage  = new AboutPage();
}
