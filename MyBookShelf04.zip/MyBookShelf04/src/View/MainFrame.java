/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package View;

import Service.MyBookService;
import View.pages.MyArchivePage;
import View.pages.MyBookPage;
import View.pages.PageController;
import View.pages.homepage;

/**
 *
 * @author ASUS
 */
public class MainFrame extends javax.swing.JFrame {
    private MyBookService myBookService;
    /**
     * Creates new form MainFrame
     */
    public MainFrame() {
        initComponents();

        panelPage.removeAll();
        homepage hp = new homepage();
        panelPage.add(hp);
        repaint();
        revalidate();
    }

    public void setMyBookService(MyBookService myBookService) {
        this.myBookService = myBookService;
    }

    void resetData() {
        btnHome.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/home-page.png")));
        btnMyBook.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/open-book.png")));
        btnArchive.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/archive.png")));
        btnAbout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/id-card.png")));
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        lblTitle = new javax.swing.JLabel();
        btnArchive = new javax.swing.JButton();
        btnMyBook = new javax.swing.JButton();
        btnAbout = new javax.swing.JButton();
        btnHome = new javax.swing.JButton();
        panelPage = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(63, 81, 181));

        lblTitle.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblTitle.setForeground(new java.awt.Color(255, 255, 255));
        lblTitle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTitle.setText("HOME");

        btnArchive.setBackground(new java.awt.Color(63, 81, 181));
        btnArchive.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/archive.png"))); // NOI18N
        btnArchive.setBorderPainted(false);
        btnArchive.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnArchiveActionPerformed(evt);
            }
        });

        btnMyBook.setBackground(new java.awt.Color(63, 81, 181));
        btnMyBook.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/open-book.png"))); // NOI18N
        btnMyBook.setBorderPainted(false);
        btnMyBook.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMyBookActionPerformed(evt);
            }
        });

        btnAbout.setBackground(new java.awt.Color(63, 81, 181));
        btnAbout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/id-card.png"))); // NOI18N
        btnAbout.setBorderPainted(false);
        btnAbout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAboutActionPerformed(evt);
            }
        });

        btnHome.setBackground(new java.awt.Color(63, 81, 181));
        btnHome.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/home_onn.png"))); // NOI18N
        btnHome.setBorderPainted(false);
        btnHome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHomeActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(55, 55, 55)
                .addComponent(btnHome)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 90, Short.MAX_VALUE)
                .addComponent(btnMyBook)
                .addGap(67, 67, 67)
                .addComponent(btnArchive)
                .addGap(89, 89, 89)
                .addComponent(btnAbout)
                .addGap(62, 62, 62))
            .addComponent(lblTitle, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(lblTitle)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnArchive, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnMyBook, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnAbout, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnHome, javax.swing.GroupLayout.Alignment.TRAILING)))
        );

        panelPage.setLayout(new javax.swing.BoxLayout(panelPage, javax.swing.BoxLayout.LINE_AXIS));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(panelPage, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(panelPage, javax.swing.GroupLayout.DEFAULT_SIZE, 432, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnHomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHomeActionPerformed

        panelPage.removeAll();
        panelPage.add(PageController.hp);
        resetData();
        
        lblTitle.setText("HOME");
        btnHome.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/home_onn.png")));
        repaint();
        revalidate();
    }//GEN-LAST:event_btnHomeActionPerformed

    private void btnMyBookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMyBookActionPerformed
        panelPage.removeAll();
        MyBookPage bookPage = new MyBookPage();
        myBookService.setTableMyBook(bookPage.getTblMyBook());
        bookPage.setMyBookService(myBookService);
        panelPage.add(bookPage);
        resetData();

        lblTitle.setText("MyBook");
        btnMyBook.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/mybook_on.png")));
        repaint();
        revalidate();
    }//GEN-LAST:event_btnMyBookActionPerformed

    private void btnAboutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAboutActionPerformed
        
        panelPage.removeAll();
        panelPage.add(PageController.aboutPage);
        resetData();
        
        lblTitle.setText("About");
        btnAbout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/id_on.png")));
    }//GEN-LAST:event_btnAboutActionPerformed

    private void btnArchiveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnArchiveActionPerformed
        
        panelPage.removeAll();
        MyArchivePage myArchivePage = new MyArchivePage();
        myBookService.setTableArchived(myArchivePage.getTblMyArchived());
        myArchivePage.setMyArchivedService(myBookService);
        panelPage.add(myArchivePage);
        resetData();
        
        lblTitle.setText("MyArchive");
        btnArchive.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/archive_on.png")));
        repaint();
        revalidate();
    }//GEN-LAST:event_btnArchiveActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAbout;
    private javax.swing.JButton btnArchive;
    private javax.swing.JButton btnHome;
    private javax.swing.JButton btnMyBook;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JPanel panelPage;
    // End of variables declaration//GEN-END:variables
}
