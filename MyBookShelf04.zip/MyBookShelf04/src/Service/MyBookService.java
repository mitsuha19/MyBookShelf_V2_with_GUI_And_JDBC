package Service;

import Entity.MyBook;
import javax.swing.JTable;

public interface MyBookService {
    
    public boolean readingMyBook(int isbn);
    
    public void showMyBook(String keyword,String cbxstatus);
    
    void setTableMyBook (JTable tblMyBook);
    
    void setTableArchived (JTable tblArchived);
    
    void showMyArchived(String keyword,String cbxstatus);
    
    void tableHandling();
    
    void tableArchivedHandling();
    
    void loadData(String keyword,String cbxStat);
    
    void loadDataArchived(String keyword,String cbxStat);
     
    public void addMyBook(int isbn, String title, String author, String publisher, int year, int totalPages);
    
    public void removeMyBook(int isbn);
    
    public void changeStatus(int isbn, boolean status);
    
    public void changeTitle(int isbn, String judul);
    
    public MyBook getByIsbn(int isbn);
    
    public void updateReadingMyBook(int isbn, int currentPages);
    
    public void showMyBookWithoutArchived();
    
    public void showMyBookOnlyArchived();
    
    public void updateArchivedMyBook(int isbn, boolean isArchived);

}
