package Service;

import Entity.MyBook;
import Repository.MyBookRepository;
import Util.ButtonEditor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.EventObject;
import javax.swing.DefaultCellEditor;
import javax.swing.JCheckBox;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.CellEditorListener;
import javax.swing.event.ChangeEvent;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;

public class MyBookServiceImpl implements MyBookService {

    private MyBookRepository myBookRepository;
    private JTable tblMyBook;
    private JTable tblArchived;

    public MyBookServiceImpl(MyBookRepository myBookRepository) {
        this.myBookRepository = myBookRepository;
    }

    @Override 
    public MyBook getByIsbn(int isbn) {
        return myBookRepository.get(isbn);
    }
    
    @Override
    public void setTableMyBook(JTable tblMyBook) {
        this.tblMyBook = tblMyBook;
        System.out.println("show table");
        showMyBook("","");
    }

    @Override
    public void setTableArchived(JTable tblArchived) {
        this.tblArchived = tblArchived;
        System.out.println("Show table archived");
        showMyArchived("","");
    }

    @Override
    public void tableHandling() {
        try {
            JTable tblTodo = this.tblMyBook;
            tblMyBook.getColumnModel().getColumn(0).setCellEditor(new DefaultCellEditor(new JTextField()) {
                @Override
                public boolean isCellEditable(EventObject anEvent) {
                    return false;
                }
            });

//            tblMyBook.getColumnModel().getColumn(1).setCellEditor(new DefaultCellEditor(new JTextField()) {
//                @Override
//                  public boolean isCellEditable(EventObject anEvent) {
//                        return false;
//                  }
//            });

            {

                ButtonEditor btnArchive = new ButtonEditor(new JCheckBox());
                btnArchive.button.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        int row = tblMyBook.getSelectedRow();
                        int column = tblMyBook.getSelectedColumn();
                        DefaultTableModel model = (DefaultTableModel) tblTodo.getModel();

                        if (row >= 0 && column == 2) {
                            int MyIsbn = (int) model.getValueAt(row, 0);
                            MyBook book = myBookRepository.get(MyIsbn);
                            book.setArchived(true);
                            changeStatus(MyIsbn, true);
                            showMyBook("","");
                        }

                    }
                });

                tblMyBook.getColumnModel().getColumn(2).setCellRenderer(new Util.ButtonRenderer());
                tblMyBook.getColumnModel().getColumn(2).setCellEditor(btnArchive);
                // Membuat Button untuk kolom di JTable
                {
                    // Membuat Button Editor untuk ditambahkan ke kolom JTabel
                    ButtonEditor btnDeleteEditor = new ButtonEditor(new JCheckBox());
                    // Menambahkan ActionListener ke Button yang ada di Button Editor
                    btnDeleteEditor.button.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            System.out.println("Test");
                            int row = tblTodo.getSelectedRow();
                            int column = tblTodo.getSelectedColumn();
                            DefaultTableModel model = (DefaultTableModel) tblTodo.getModel();

                            if (row >= 0 && column == 3) {
                                int isbn = (int) model.getValueAt(row, 0);
                                removeMyBook(isbn);
                                showMyBook("","");
                            }

                        }
                    });
                    // Menambahkan Button Editor ke JTable
                    tblTodo.getColumnModel().getColumn(3).setCellRenderer(new Util.ButtonRenderer());
                    tblTodo.getColumnModel().getColumn(3).setCellEditor(btnDeleteEditor);
                }

                // Menambahkan CellEditorListener untuk menangkap perubahan pada kolom di JTable
                tblTodo.getDefaultEditor(String.class).addCellEditorListener(new CellEditorListener() {
                    @Override
                    public void editingStopped(ChangeEvent e) {
                        int row = tblTodo.getSelectedRow();
                        int column = tblTodo.getSelectedColumn();
                        String selectedValue = tblTodo.getValueAt(row, column).toString();
                        System.out.println("Cell di baris " + row + ", kolom " + column + " diubah menjadi: " + selectedValue);
                        changeTitle((Integer) tblMyBook.getValueAt(row, 0), selectedValue);
                        showMyBook("", "");
                        
                    }

                    @Override
                    public void editingCanceled(ChangeEvent e) {
                        // aksi jika pengiditan dibatalkan
                    }
                });
            }
        } catch (Error | Exception e) {

        }
    }

    @Override
    public void tableArchivedHandling() {
        try {
            JTable tblTodo = this.tblArchived;
            tblArchived.getColumnModel().getColumn(0).setCellEditor(new DefaultCellEditor(new JTextField()) {
                @Override
                public boolean isCellEditable(EventObject anEvent) {
                    return false;
                }
            });

//            tblArchived.getColumnModel().getColumn(1).setCellEditor(new DefaultCellEditor(new JTextField()) {
//                @Override
//                public boolean isCellEditable(EventObject anEvent) {
//                    return false;
//                }
//            });

            {

                ButtonEditor btnArchive = new ButtonEditor(new JCheckBox());
                btnArchive.button.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        int row = tblArchived.getSelectedRow();
                        int column = tblArchived.getSelectedColumn();
                        DefaultTableModel model = (DefaultTableModel) tblTodo.getModel();

                        if (row >= 0 && column == 2) {
                            int MyIsbn = (int) model.getValueAt(row, 0);
                            MyBook book = myBookRepository.get(MyIsbn);
                            book.setArchived(true);
                            changeStatus(MyIsbn, false);
                            showMyArchived ("","");               
                        }

                    }
                });

                tblArchived.getColumnModel().getColumn(2).setCellRenderer(new Util.ButtonRenderer());
                tblArchived.getColumnModel().getColumn(2).setCellEditor(btnArchive);
                // Membuat Button untuk kolom di JTable
                {
                    // Membuat Button Editor untuk ditambahkan ke kolom JTabel
                    ButtonEditor btnDeleteEditor = new ButtonEditor(new JCheckBox());
                    // Menambahkan ActionListener ke Button yang ada di Button Editor
                    btnDeleteEditor.button.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            int row = tblTodo.getSelectedRow();
                            int column = tblTodo.getSelectedColumn();
                            DefaultTableModel model = (DefaultTableModel) tblTodo.getModel();

                            if (row >= 0 && column == 3) {
                                int isbn = (int) model.getValueAt(row, 0);
                                removeMyBook(isbn);
                                showMyArchived("","");
                            }

                        }
                    });
                    // Menambahkan Button Editor ke JTable
                    tblArchived.getColumnModel().getColumn(3).setCellRenderer(new Util.ButtonRenderer());
                    tblArchived.getColumnModel().getColumn(3).setCellEditor(btnDeleteEditor);
                }

                // Menambahkan CellEditorListener untuk menangkap perubahan pada kolom di JTable
                tblTodo.getDefaultEditor(String.class).addCellEditorListener(new CellEditorListener() {
                    @Override
                    public void editingStopped(ChangeEvent e) {
                        int row = tblTodo.getSelectedRow();
                        int column = tblTodo.getSelectedColumn();
                        String selectedValue = tblTodo.getValueAt(row, column).toString();
                        System.out.println("Cell di baris " + row + ", kolom " + column + " diubah menjadi: " + selectedValue);
                        changeTitle((Integer) tblArchived.getValueAt(row, 0), selectedValue);
                        showMyArchived("", "");
                    }

                    @Override
                    public void editingCanceled(ChangeEvent e) {
                        // aksi jika pengiditan dibatalkan
                    }
                });
            }
        } catch (Error | Exception e) {

        }
    }

    @Override
    public void loadData(String keyword,String cbxStat) {
        JTable tblMyBook = this.tblMyBook;
        ArrayList<MyBook> model = myBookRepository.getAll(keyword,"Tidak Archived");
        System.out.println("data table " + model.toString());
        DefaultTableModel tableModel = new DefaultTableModel(null, new Object[]{"ISBN", "Judul", "Status", "Aksi"}) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return true;
            }
        };

        if (!model.isEmpty()) {
            for (var i = 0; i < model.size(); i++) {
                var mybook = model.get(i);
                var status = "Tidak Archived";

                if (mybook != null) {
                    if (mybook.isArchived()) {
                        status = "Archived";
                    }
                    tableModel.addRow(new Object[]{mybook.getIsbn(), mybook.getTitle(), status, "Hapus"});
                }
            }
        }

        tblMyBook.setModel(tableModel);
        tblMyBook.setCellSelectionEnabled(false);
        tblMyBook.setRowSelectionAllowed(true);
        tblMyBook.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        tblMyBook.setRowHeight(40);

        TableColumnModel columnModel = tblMyBook.getColumnModel();

        TableColumn columnID = columnModel.getColumn(0);
        columnID.setPreferredWidth(150);

        TableColumn columnTodo = columnModel.getColumn(1);
        columnTodo.setPreferredWidth(163);

        TableColumn columnStatus = columnModel.getColumn(2);
        columnStatus.setPreferredWidth(150);

        TableColumn columnAksi = columnModel.getColumn(3);
        columnAksi.setPreferredWidth(150);
    }

    @Override
    public void loadDataArchived(String keyword,String cbxStat) {
        JTable tblArchived = this.tblArchived;
        ArrayList<MyBook> model = myBookRepository.getAll(keyword,"Archived");
        System.out.println("data table " + model.toString());
        DefaultTableModel tableModel = new DefaultTableModel(null, new Object[]{"ISBN", "Judul", "Status", "Aksi"}) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return true;
            }
        };

        if (!model.isEmpty()) {
            for (var i = 0; i < model.size(); i++) {
                var mybook = model.get(i);
                var status = "Tidak Archived";

                if (mybook != null) {
                    if (mybook.isArchived()) {
                        status = "Archived";
                    }
                    tableModel.addRow(new Object[]{mybook.getIsbn(), mybook.getTitle(), status, "Hapus"});
                }
            }
        }

        tblArchived.setModel(tableModel);
        tblArchived.setCellSelectionEnabled(false);
        tblArchived.setRowSelectionAllowed(true);
        tblArchived.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        tblArchived.setRowHeight(40);

        TableColumnModel columnModel = tblArchived.getColumnModel();

        TableColumn columnID = columnModel.getColumn(0);
        columnID.setPreferredWidth(150);

        TableColumn columnTodo = columnModel.getColumn(1);
        columnTodo.setPreferredWidth(163);

        TableColumn columnStatus = columnModel.getColumn(2);
        columnStatus.setPreferredWidth(150);

        TableColumn columnAksi = columnModel.getColumn(3);
        columnAksi.setPreferredWidth(150);
    }

    @Override
    public void showMyBook(String keyword,String cbxstatus) {
        loadData(keyword,cbxstatus);
        tableHandling();
    }

    @Override
    public void showMyArchived(String keyword,String cbxstatus) {
        loadDataArchived(keyword,cbxstatus);
        tableArchivedHandling();
    }

    @Override
    public void addMyBook(int isbn, String title, String author, String publisher, int year, int totalPages) {
        MyBook myBook = new MyBook(isbn, title, author, publisher, year, totalPages);

        boolean success = myBookRepository.add(myBook);

        if (success) {
            System.out.println("SUKSES MENAMBAH TODO : " + myBook.getTitle());
        } else {
            System.out.println("GAGAL MENAMBAH TODO : " + myBook.getTitle() + ". Panjang karakter minimal 6.");
        }

        showMyBook("","");
    }

    @Override
    public void removeMyBook(int isbn) {
        boolean succes = myBookRepository.remove(isbn);
        if (succes) {
            System.out.println("SUKSES MENGHAPUS MY BOOK : " + isbn);
        } else {
            System.out.println("GAGAL MENGHAPUS MY BOOK : " + isbn);
        }
    }

    @Override
    public void changeStatus(int isbn, boolean status) {
        System.out.println("isbn: " + isbn);
        boolean result = myBookRepository.changeStatus(isbn, status);
        if (result) {
            System.out.println("SUKSES MENGUBAH TODO : posisi ke-" + isbn + " menjadi " + status);
        } else {
            System.out.println("GAGAL MENGUBAH TODO : posisi ke-" + isbn + " menjadi " + status + ". Todo tidak tersedia.");
        }
    }
    
    @Override
    public void changeTitle(int isbn, String judul) {
        System.out.println("isbn : " + isbn);
        boolean result = myBookRepository.changeTittle(isbn, judul);
        
        if (result) {
            System.out.println("SUKSES MENGUBAH TODO : posisi ke-" + isbn + " menjadi " + judul);
        } else {
            System.out.println("GAGAL MENGUBAH TODO : posisi ke-" + isbn + " menjadi " + judul + ". Todo tidak tersedia.");
        }
    }

    @Override
    public void updateReadingMyBook(int isbn, int currentPages) {
        System.out.println("reading book");
        
        boolean result = myBookRepository.updateReading(isbn, currentPages);
        
        if (result) {
            System.out.println("SUKSES MEMBACA");
        } else {
            System.out.println("GAGAL MEMBACA");
        }
        
    }

    @Override
    public boolean readingMyBook(int isbn) {
        MyBook membaca = null;
        boolean succes = false;

//        for (MyBook myBook : myBookRepository.getAll()) {
//            if (myBook.getIsbn() == isbn) {
//                membaca = myBook;
//                System.out.println("Informasi Buku :");
//                System.out.println("ISBN : " + membaca.getIsbn());
//                System.out.println("Judul : " + membaca.getTitle());
//                System.out.println("Penulis : " + membaca.getAuthor());
//                System.out.println("Penerbit : " + membaca.getPublisher());
//                System.out.println("Tahun Terbit : " + membaca.getYear());
//                System.out.println("Jumlah Halaman : " + membaca.getTotalPages());
//                System.out.println("Halaman Terakhir Dibaca : " + membaca.getCurrentPages());
//                System.out.println("Status Arsip : Tidak Diarsipkan");
//                System.out.println();
//
//                var inginMembaca = InputUtil.input("Halaman saat ini");
//                System.out.println();
//
//                int numMembaca = Integer.parseInt(inginMembaca);
//                if (numMembaca > membaca.getTotalPages() || numMembaca < 0) {
//                    System.out.println("GAGAL MEMBACA MY BOOK : " + membaca.getIsbn() + " sampai halaman " + numMembaca);
//                } else {
//                    membaca.setCurrentPages(numMembaca);
//                    System.out.println("SUKSES MEMBACA MY BOOK : " + membaca.getIsbn() + " sampai halaman " + membaca.getCurrentPages());
//                    succes = myBookRepository.updateReading(isbn, numMembaca);;
//                }
//                break;
//            } else {
//                System.out.println("Buku dengan ISBN " + isbn + " belum tersedia");
//                System.out.println();
//            }
//        }
        return succes;
    }

    @Override
    public void showMyBookWithoutArchived() {
        ArrayList<MyBook> tanpaArchive = myBookRepository.getWithoutArchived();
        System.out.println("My Book :");
        if (tanpaArchive.size() > 0) {
            for (int i = 0; i < tanpaArchive.size(); i++) {
                var mybook = tanpaArchive.get(i);
                System.out.println(mybook.getIsbn() + ". " + mybook.getTitle() + " [" + mybook.getCurrentPages() + "/" + mybook.getTotalPages() + "]");
            }
        } else {
            System.out.println("Belum ada daftar buku yang tersedia");
        }
        System.out.println();

    }

    @Override
    public void showMyBookOnlyArchived() {
        ArrayList<MyBook> denganArchive = myBookRepository.getOnlyArchived();
        System.out.println("My Book (Diarsipkan) :");
        if (denganArchive.size() > 0) {
            for (int i = 0; i < denganArchive.size(); i++) {
                var mybook = denganArchive.get(i);
                System.out.println(mybook.getIsbn() + ". " + mybook.getTitle() + " [" + mybook.getCurrentPages() + "/" + mybook.getTotalPages() + "]");
            }
        } else {
            System.out.println("Belum ada daftar buku yang tersedia");
        }
        System.out.println();
    }

    @Override
    public void updateArchivedMyBook(int isbn, boolean isArchived) {
        MyBook isexist = null;

//        for (MyBook myBook : myBookRepository.getAll()) {
//            if (myBook.getIsbn() == isbn) {
//                isexist = myBook;
//                break;
//            }
//
//        }
//        if (isArchived && isexist != null) {
//            System.out.println("SUKSES MENGARSIPKAN MY BOOK : " + isbn + " menjadi diarsipkan");
//            myBookRepository.updateArchived(isbn, isArchived);
//        } else if (!isArchived && isexist != null) {
//            System.out.println("SUKSES MENGARSIPKAN MY BOOK : " + isbn + " menjadi batal diarsipkan");
//            myBookRepository.updateArchived(isbn, isArchived);
//        } else {
//            System.out.println("GAGAL MENGARSIPKAN MY BOOK : " + isbn + " menjadi diarsipkan");
//        }
    }

}
